-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 12, 2023 at 11:48 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gadgetsonwheels`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertData` (IN `name` VARCHAR(255), IN `email` VARCHAR(255), IN `comments` VARCHAR(1000))   INSERT INTO feedback(name,email,feedback) VALUES (name, email,comments)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `username`, `password`, `created_at`) VALUES
(1, 'karan', '$2y$10$jYsJKKx.gRJvX3AIJBh7w.aNMG7F6ovETLajmkTo9DZIZRKohCh1.', '2023-01-12 14:52:43');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `total_price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`p_id`, `product_name`, `product_price`, `product_image`, `qty`, `total_price`) VALUES
(20, 'Acer Aspire 5s', '5000', 'img/ac.webp', 1, '5000');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`) VALUES
(1, 'mobiles'),
(2, 'laptops'),
(3, 'tv'),
(4, 'camera'),
(5, 'gaming'),
(6, 'headphone'),
(7, 'speaker'),
(8, 'projector');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `feedback` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `feedback`) VALUES
(1, 'karan', 'karan@gmil.com', 'good service');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_name` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `p_id`, `p_name`, `action`, `date`) VALUES
(1, 1, 'Canon DSLR', 'INSERTED', '2023-01-12 15:18:53'),
(2, 2, 'Canon DSLR', 'INSERTED', '2023-01-12 15:20:36'),
(3, 3, 'Play station 5', 'INSERTED', '2023-01-12 15:32:47'),
(4, 4, 'Poco Phone', 'INSERTED', '2023-01-12 15:35:36'),
(5, 5, 'Samsung Galaxy', 'INSERTED', '2023-01-12 15:37:35'),
(6, 6, 'Vivo', 'INSERTED', '2023-01-12 15:39:28'),
(7, 7, 'Samsung Galaxy', 'INSERTED', '2023-01-12 15:41:44'),
(8, 8, 'Sony Bravia', 'INSERTED', '2023-01-12 15:43:23'),
(9, 9, 'Samsung TV', 'INSERTED', '2023-01-12 15:45:04'),
(10, 10, 'MI TV', 'INSERTED', '2023-01-12 15:46:20'),
(11, 11, 'LG TV', 'INSERTED', '2023-01-12 15:47:55'),
(12, 12, 'Sony Speakers', 'INSERTED', '2023-01-12 15:49:47'),
(13, 13, 'MI Smart Speaker', 'INSERTED', '2023-01-12 15:52:06'),
(14, 14, 'JBL Speaker', 'INSERTED', '2023-01-12 15:53:31'),
(15, 15, 'Sony Headphones', 'INSERTED', '2023-01-12 15:56:15'),
(16, 16, 'Boat Headphone', 'INSERTED', '2023-01-12 15:57:11'),
(17, 17, 'JBL Headphones', 'INSERTED', '2023-01-12 15:58:12'),
(18, 18, 'Apple Airpods Max', 'INSERTED', '2023-01-12 15:59:13'),
(19, 19, 'Lenovo Laptop', 'INSERTED', '2023-01-12 16:01:07'),
(20, 20, 'Acer Aspire 5s', 'INSERTED', '2023-01-12 16:03:12'),
(21, 21, 'XBOX Controller', 'INSERTED', '2023-01-12 16:05:02'),
(22, 22, 'Play station Control', 'INSERTED', '2023-01-12 16:06:09'),
(23, 23, 'XBOX Controller', 'INSERTED', '2023-01-12 16:07:19'),
(24, 24, 'Epson Projector', 'INSERTED', '2023-01-12 16:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `pmode` varchar(50) NOT NULL,
  `due_date` date NOT NULL,
  `products` varchar(255) NOT NULL,
  `amount_paid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `name`, `email`, `phone`, `address`, `pmode`, `due_date`, `products`, `amount_paid`) VALUES
(1, 1, 'karan', 'karan@gmil.com', '7411681221', 'bangalore', 'netbanking', '2023-01-21', 'Lenovo Laptop(1)', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `qty` int(255) NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `cat_num` int(2) NOT NULL,
  `p_image` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_name`, `qty`, `price`, `description`, `cat_num`, `p_image`) VALUES
(1, 'Canon DSLR', 1, 550, 'DSLR camera', 4, 'img/camera.jfif'),
(2, 'Canon DSLR', 1, 560, 'DSLR camera', 4, 'img/dslr.jpg'),
(3, 'Play station 5', 1, 4500, 'AMD RDNA2 GPU 36 CUs@2.23GHz', 5, 'img/gaming.jpg'),
(4, 'Poco Phone', 1, 1100, 'Snapdragon 845', 1, 'img/poco.jfif'),
(5, 'Samsung Galaxy', 1, 3500, 'Exynos processor', 1, 'img/samsung.jfif'),
(6, 'Vivo', 1, 1150, 'Mediatek Helio G35', 1, 'img/vivo1.jpeg'),
(7, 'Samsung Galaxy', 1, 4000, 'Snapdragon 855', 1, 'img/sam.jfif'),
(8, 'Sony Bravia', 1, 5700, '49 Inch 4K TV', 3, 'img/sony.jpg'),
(9, 'Samsung TV', 1, 3000, '43 Inch UHD TV', 3, 'img/samsung tv.webp'),
(10, 'MI TV', 1, 2300, '43 Inch 4k TV', 3, 'img/mitv.jpg'),
(11, 'LG TV', 1, 2500, '43 Inch 4k TV', 3, 'img/lgtv.jpg'),
(12, 'Sony Speakers', 1, 2500, '60W speakers', 7, 'img/speakers.png'),
(13, 'MI Smart Speaker', 1, 2000, 'Smart Speaker with Alexa built in', 7, 'img/smartsp.png'),
(14, 'JBL Speaker', 1, 1200, 'Computer Speakers', 7, 'img/jbl.webp'),
(15, 'Sony Headphones', 1, 1700, '40mm driver with full bass', 6, 'img/headphones.jpg'),
(16, 'Boat Headphone', 1, 250, 'Boat Bass headphones', 6, 'img/boat.jpg'),
(17, 'JBL Headphones', 1, 500, 'Bass Headphones', 6, 'img/jblhead.jpg'),
(18, 'Apple Airpods Max', 1, 3000, '50mm driver', 6, 'img/airpodsmax.jfif'),
(19, 'Lenovo Laptop', 1, 2000, 'Intel i7', 2, 'img/lenovo.jfif'),
(20, 'Acer Aspire 5s', 1, 5000, 'Intel i5', 2, 'img/ac.webp'),
(21, 'XBOX Controller', 1, 500, 'microsoft gaming controller', 5, 'img/xboxc.jpg'),
(22, 'Play station Controller', 1, 500, 'Sony Gaming Controller', 5, 'img/psc.jpg'),
(23, 'XBOX Controller', 1, 500, 'microsoft gaming controller', 5, 'img/xbox2.jfif'),
(24, 'Epson Projector', 1, 5000, '4K projector', 8, 'img/projector.jpg');

--
-- Triggers `products`
--
DELIMITER $$
CREATE TRIGGER `deletelog` AFTER DELETE ON `products` FOR EACH ROW INSERT INTO logs VALUES(null,OLD.p_id,OLD.p_name,'DELETED',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insertlog` AFTER INSERT ON `products` FOR EACH ROW INSERT INTO logs VALUES (null, NEW.p_id,NEW.p_name,'INSERTED',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updatelog` AFTER UPDATE ON `products` FOR EACH ROW INSERT INTO logs VALUES(null,NEW.p_id,NEW.p_name,'UPDATED',NOW())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'karan', '$2y$10$It/YOMHeN3dNiQFEN1en4eVhLqzZbJM7YxbWuw5RkC/Dd1L9L0NBm', '2023-01-12 15:26:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `cat_num` (`cat_num`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk` FOREIGN KEY (`cat_num`) REFERENCES `categories` (`cat_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
